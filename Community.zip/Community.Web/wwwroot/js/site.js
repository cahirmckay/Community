﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.


// function initialize() {
//     mapcode = new google.maps.Geocoder();
//     var lnt = new google.maps.LatLng(54.67, -6.66);
//     const myLatLng = { lat: -25.363, lng: 131.044 };
//     const map = new google.maps.Map(document.getElementById("map"), {
//         zoom: 4,
//         center: myLatLng,
//     });

//     // new google.maps.Marker({
//     //     position: { lat: -25.363, lng: 131.044 },
//     //     map,
//     //     title: "Hello World!",
//     // });
// }




//google.maps.event.addDomListener(window, 'load', initialize);